package com.wolf.rabbit;

import android.content.Context;
import android.os.AsyncTask;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImageSender extends AsyncTask<Void, Void, Void> {
    private Context context;
    private String botToken;
    private String chatId;
    private String imagePath;

    public ImageSender(Context context, String botToken, String chatId, String imagePath) {
        this.context = context;
        this.botToken = botToken;
        this.chatId = chatId;
        this.imagePath = imagePath;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        HttpURLConnection connection = null;
        DataOutputStream outputStream = null;
        FileInputStream fileInputStream = null;

        try {
            URL url = new URL("https://api.telegram.org/bot" + botToken + "/sendPhoto?chat_id=" + chatId);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "multipart/form-data");

            outputStream = new DataOutputStream(connection.getOutputStream());
            fileInputStream = new FileInputStream(imagePath);

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.flush();
            outputStream.close();
            fileInputStream.close();

            int responseCode = connection.getResponseCode();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
